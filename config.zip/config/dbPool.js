const mysql = require('promise-mysql');	// mysql 모듈의 promise 버전

// rds 정보 입력 : hostname, username, password, default DB
const dbConfig = {
	host : 'sopt-server.cb22vz4dnf9n.us-east-2.rds.amazonaws.com',
	port : 3306,
	user : 'sopt_song',
	password : 'toortoor',
	database : 'hapdong',
	connectionLimit : 20
};

module.exports = mysql.createPool(dbConfig);// connection pool을 module화